import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class App {
    private static Connection connection;
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) throws Exception {
        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/nome_do_banco", "root", "");
            System.out.println("Conexão com o banco de dados estabelecida com sucesso!");

            executarPrograma();

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Erro ao conectar com o banco de dados!");
        } finally {
            if (connection != null) {
                connection.close();
            }
        }
    }

    public static void executarPrograma() {
        System.out.println("Bem-vindo à Livraria JavaBooks!");
        System.out.println("Aqui você pode cadastrar-se, escolher livros e realizar o pagamento.");

        System.out.println("\nCadastro de Usuário");
        System.out.print("Digite seu nome: ");
        String nomeUsuario = scanner.nextLine();
        System.out.print("Digite seu e-mail: ");
        String emailUsuario = scanner.nextLine();

        // Inserir usuário na tabela usuarios
        inserirUsuario(nomeUsuario, emailUsuario);

        Map<String, Double> carrinho = new HashMap<>();
        double totalCompra = 0.0;

        Map<Integer, Livro> livros = new HashMap<>();
        livros.put(1, new Livro("O Senhor dos Anéis", 79.90));
        livros.put(2, new Livro("Harry Potter e a Pedra Filosofal", 39.90));
        livros.put(3, new Livro("Dom Quixote", 29.90));

        System.out.println("\nLivros Disponíveis:");
        for (Map.Entry<Integer, Livro> entry : livros.entrySet()) {
            Livro livro = entry.getValue();
            System.out.println(entry.getKey() + ". " + livro.getTitulo() + " - Preço: R$" + livro.getPreco());
        }

        while (true) {
            System.out.println("\nEscolha o número do livro desejado (digite o número) ou digite '0' para finalizar:");
            int livroEscolhido = scanner.nextInt();
            if (livroEscolhido == 0) {
                break;
            }
            Livro livroSelecionado = livros.get(livroEscolhido);
            if (livroSelecionado == null) {
                System.out.println("Livro não encontrado. Por favor, tente novamente.");
                continue;
            }
            double precoLivro = livroSelecionado.getPreco();
            System.out.println("Livro adicionado ao carrinho: " + livroSelecionado.getTitulo() + " - Preço: R$" + precoLivro);
            carrinho.put(livroSelecionado.getTitulo(), precoLivro);
            totalCompra += precoLivro;
        }

        System.out.println("\nCarrinho de Compras:");
        for (Map.Entry<String, Double> entry : carrinho.entrySet()) {
            System.out.println(entry.getKey() + " - Preço: R$" + entry.getValue());
        }
        System.out.println("Total da compra: R$" + totalCompra);

        System.out.println("\nEscolha a forma de pagamento:");
        System.out.println("1. Cartão de Débito");
        System.out.println("2. Cartão de Crédito");
        System.out.println("3. PIX");
        System.out.println("4. Vales");
        int opcaoPagamento = scanner.nextInt();

        switch (opcaoPagamento) {
            case 1:
                System.out.println("Pagamento com cartão de débito selecionado.");
                break;
            case 2:
                System.out.println("Pagamento com cartão de crédito selecionado.");
                break;
            case 3:
                System.out.println("Pagamento com PIX selecionado.");
                break;
            case 4:
                System.out.println("Pagamento com vales selecionado.");
                break;
            default:
                System.out.println("Opção inválida.");
        }

        System.out.println("\n===== Nota Fiscal =====");
        System.out.println("Nome do Cliente: " + nomeUsuario);
        System.out.println("Email do Cliente: " + emailUsuario);
        System.out.println("Itens Comprados:");
        for (Map.Entry<String, Double> entry : carrinho.entrySet()) {
            System.out.println(entry.getKey() + " - Preço: R$" + entry.getValue());
        }
        System.out.println("Total da compra: R$" + totalCompra);
    }

    public static void inserirUsuario(String nome, String email) {
        try {
            String sql = "INSERT INTO usuarios (nome, email) VALUES (?, ?)";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, nome);
            statement.setString(2, email);
            statement.executeUpdate();
            System.out.println("Usuário cadastrado com sucesso!");
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Erro ao inserir usuário.");
        }
    }
}

class Livro {
    private String titulo;
    private double preco;

    public Livro(String titulo, double preco) {
        this.titulo = titulo;
        this.preco = preco;
    }

    public String getTitulo() {
        return titulo;
    }

    public double getPreco() {
        return preco;
    }
}